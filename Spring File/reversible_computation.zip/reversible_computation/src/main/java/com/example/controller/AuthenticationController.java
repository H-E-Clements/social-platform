package com.example.controller;

import com.example.domain.Users;
import com.example.repository.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.security.Principal;

@Controller
public class AuthenticationController {

    @Autowired
    UsersRepository repo;

    @RequestMapping(value = "/login-form", method = RequestMethod.GET)
    public String loginForm() {
        return "security/login";
    }

    @RequestMapping(value = "/error-login", method = RequestMethod.GET)
    public String invalidLogin(Model model) {
        model.addAttribute("error", true);
        return "security/login";
    }

    /**
     * Successful login is a redirect based on the role of the user
     *
     * @param principal
     * @return
     */
    @RequestMapping(value = "/success-login", method = RequestMethod.GET)
    public String successLogin(Principal principal) {
        Users user = repo.findByName(principal.getName());
        if (user.getRoles().isEmpty()) {
            return "security/denied";
        }
        return "redirect:/needlogin";
    }

    @RequestMapping(value = "/access-denied", method = RequestMethod.GET)
    public String error() {
        return "security/denied";
    }
}
