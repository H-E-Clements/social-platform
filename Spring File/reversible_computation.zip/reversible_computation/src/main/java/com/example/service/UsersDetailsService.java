package com.example.service;

import com.example.domain.Roles;
import com.example.domain.Users;
import com.example.repository.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UsersDetailsService implements org.springframework.security.core.userdetails.UserDetailsService {

    @Autowired
    private UsersRepository repo;


    @Override
    public UserDetails loadUserByUsername(String login) throws UsernameNotFoundException {

        Users domainUser = repo.findByName(login);

        List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
        for (Roles r : domainUser.getRoles()) {
            authorities.add(new SimpleGrantedAuthority("ROLE_" + r.getName()));
        }

        return new User(domainUser.getName(), domainUser.getPassword(), true,
                true, true, true, authorities);
    }
}
