package com.example;

import com.example.domain.Roles;
import com.example.domain.Users;
import com.example.repository.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootApplication
public class ReversibleComputationApplication implements ApplicationRunner {

    @Autowired
    private UsersRepository repo;

    public static void main(String[] args) {
        SpringApplication.run(ReversibleComputationApplication.class, args);
    }

    @Autowired
    private PasswordEncoder pe;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        Users u1 = new Users();
        u1.setName("guest");
        u1.setPassword(pe.encode("password"));

        Roles r1 = new Roles();
        r1.setName("registered");

        u1.getRoles().add(r1);

        repo.save(u1);
    }

}
